import java.util.Scanner;

public class Fibonacci {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter index:");
        int index =sc.nextInt();
        fibonacci(index);
    }

    static void fibonacci(int index) {
       if(index< 0){
            System.out.println("Errore: la serie di Fibonacci parte da 0");
            return;
        }
        int[] fibonacci = new int[index + 1];
        fibonacci[0] = 0;
        if(index > 0){
            fibonacci[1] = 1;
            if (index > 1) {
                for (int i = 2; i < fibonacci.length; i++) {
                    fibonacci[i]= fibonacci[i-1] + fibonacci[i-2];
                }
            }
        }
        System.out.println(fibonacci[index]);
    }
}




