public class NumeroPrimo {

    public static void main(String[] args) {
        int number = 0;
        System.out.println(isPrime(number));
        number = 1;
        System.out.println(isPrime(number));
        number = 2;
        System.out.println(isPrime(number));
        number = 17;
        System.out.println(isPrime(number));
        number = 631;
        System.out.println(isPrime(number));
        number = 634;
        System.out.println(!isPrime(number));
        number = 999;
        System.out.println(!isPrime(number));
        number = 997;
        System.out.println(isPrime(number));
    }

    private static boolean isPrime(int number) {
        if(number > 2){
            if(number%2==0)
                return false;
            else
            {
                int flag=0;
                for (int i = 3; i < number/2; i=i+2) {
                    if(number%i==0){
                        return false;
                    }
                    else
                        flag=1;
                }
                if(flag==1)
                    return true;
            }
        }
        return true;
    }
}
