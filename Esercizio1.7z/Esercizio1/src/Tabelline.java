import java.util.Arrays;
import java.util.Scanner;

public class Tabelline {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Inserisci due numeri: ");
        int m = sc.nextInt();
        int n= sc.nextInt();
        System.out.println(Arrays.toString(arrayInteri(m,n)));
    }

    static int[] arrayInteri(int m, int n){
        int[] array= new int[m];
        for (int i = 0; i < m; i++) {
            array[i]=i*n;
        }
        return array;
    }



}
